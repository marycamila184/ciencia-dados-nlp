# icd202002

## Cidades a serem analisadas

Nesta fase do trabalho nos optamos por unir 2 datasets com informações sobre as cidades:

IBGE2019 - Informações sobre as cidades como habitantes, população, etc.
COVIDIO - Informações com as top 100 cidades por numero de obitos acumulados

Optamos por fazer a extração de tweets das prefeituras com perfil no twitter. Obtivemos um total de aproximadamente 200 mil. 
Estamos trabalhando na limpeza para a analise

------------

